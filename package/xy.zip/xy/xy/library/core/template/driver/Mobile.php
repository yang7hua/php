<?php
// +----------------------------------------------------------------------
// | XyPHP [ WE CAN DO IT JUST XY IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2014 http://xyphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: luofei614<weibo.com/luofei614>
// +----------------------------------------------------------------------
namespace Core\Template\Driver;

/**
 * MobileTemplate模板引擎驱动
 */
class Mobile
{

    /**
     * 渲染模板输出
     *
     * @access public
     * @param string $templateFile
     *            模板文件名
     * @param array $var
     *            模板变量
     * @return void
     */
    public function fetch($templateFile, $var)
    {
        $templateFile = substr($templateFile, strlen(THEME_PATH));
        $var['_xy_template_path'] = $templateFile;
        exit(json_encode($var));
    }
}
