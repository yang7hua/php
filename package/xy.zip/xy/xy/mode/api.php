<?php
// +----------------------------------------------------------------------
// | XyPHP [ WE CAN DO IT JUST XY IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2014 http://xyphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

/**
 * XyPHP API模式定义
 */
return array(
    // 配置文件
    'config' => array(
        XY_PATH . 'Conf/convention.php', // 系统惯例配置
        CONF_PATH . 'config' . CONF_EXT
    ) // 应用公共配置
,
    
    // 别名定义
    'alias' => array(
        'Core\Exception' => CORE_PATH . 'Exception' . EXT,
        'Core\Model' => CORE_PATH . 'Model' . EXT,
        'Core\Db' => CORE_PATH . 'Db' . EXT,
        'Core\Cache' => CORE_PATH . 'Cache' . EXT,
        'Core\Cache\Driver\File' => CORE_PATH . 'Cache/Driver/File' . EXT,
        'Core\Storage' => CORE_PATH . 'Storage' . EXT
    ),
    
    // 函数和类文件
    'core' => array(
        MODE_PATH . 'Api/functions.php',
        COMMON_PATH . 'Common/function.php',
        MODE_PATH . 'Api/App' . EXT,
        MODE_PATH . 'Api/Dispatcher' . EXT,
        MODE_PATH . 'Api/Controller' . EXT,
        CORE_PATH . 'Behavior' . EXT
    ),
    // 行为扩展定义
    'tags' => array()
);
