var ue = UE.getEditor("ueditor");
