$(function(){
	$("[name=tags]").on("keyup", function(e){
		if (e.keyCode == 13) {
			console.log(1);
		}
	});	
});
