<?php
// 检测PHP环境
if(version_compare(PHP_VERSION,'5.3.0','<'))  die('require PHP > 5.3.0 !');

// 开启调试模式 建议开发阶段开启 部署阶段注释或者设为false
define('APP_DEBUG', True);

// 定义应用目录
define('APP_PATH', realpath('../').'/app/');

define('WEB_PATH', realpath('./').'/');

define('XY_PATH', realpath('../xy/').'/');

define('TMPL_PATH', WEB_PATH.'tpl/');

define('BIND_MODULE', 'home');
//define('__APP__', '/');

define('JS_PATH', '/public/js');
define('CSS_PATH', '/public/css');

require XY_PATH.'Xy.php';
