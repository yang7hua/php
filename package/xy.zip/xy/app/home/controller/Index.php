<?php
namespace home\Controller;
use Core\Controller;
class Index extends Controller {
    public function index(){
		$this->display('welcome');
    }
}
