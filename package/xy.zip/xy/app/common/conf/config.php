<?php
return array(
	//'配置项'=>'配置值'
	'URL_MODEL'	=>	2,
	'URL_PARAMS_BIND'	=>	true,
	'URL_PARAMS_BIND_TYPE'	=>	1,
	'CONTROLLER_LEVEL'	=>	1,
	'URL_ROUTER_ON'	=>	true,

	'AUTOLOAD_NAMESPACE'	=>	array(
		'Apps'	=>	APP_PATH . 'Common',
		'Ueditor'	=>	LIB_PATH . 'Org/Util/Ueditor'
	),

	//'DEFAULT_C_LAYER'	=>	'',

	'DB_TYPE'	=>	'mysql',
	'DB_HOST'	=>	'127.0.0.1',
	'DB_PORT'	=>	3306,
	'DB_USER'	=>	'root',
	'DB_PWD'	=>	'mysql',
	'DB_NAME'	=>	'us',
	'DB_PREFIX'	=>	'us_',
	'DB_CHARSET'	=>	'utf8',
	'DB_DEBUG'	=>	true,
	
	'URL_CASE_INSENSITIVE'	=>	true,
	'SHOW_PAGE_TRACE'	=>	true,

	//模板目录文件夹小写
	'TPL_PATH_USE_LOWERCASE'	=>	1,
	'DEFAULT_THEME'	=>	'default',

	'TMPL_PARSE_STRING'	=>	array(
		'CSS'	=>	'/'
	),

	//用户会话时间, 30分钟
	'USER_LOGIN_EXPTIME'	=>	1800,
);	
